import {createSlice} from '@redux/toolkit';

const initialState = {
    user: {}
};

const store = createSlice({
    name: 'user',
    initialState,
    reducers: {
        create: (state, action) => {
            state.user = action.payload;
        }
    }
})

export const {create} = store.actions;